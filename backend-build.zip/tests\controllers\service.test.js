"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const app_1 = __importDefault(require("../../src/app"));
const node_test_1 = require("node:test");
const node_assert_1 = __importDefault(require("node:assert"));
const test_utils_1 = require("../test_utils");
const supertest_1 = __importDefault(require("supertest"));
const mongoose_1 = __importDefault(require("mongoose"));
const user_1 = __importDefault(require("../../src/models/user"));
const service_1 = __importDefault(require("../../src/models/service"));
const bcrypt_1 = __importDefault(require("bcrypt"));
const api = (0, supertest_1.default)(app_1.default);
const base_url = "/api/services";
const login = (user) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    const response = yield api
        .post("/api/login")
        .send(user);
    const csrfToken = response.headers["x-csrf-token"];
    const setCookie = response.headers["set-cookie"];
    (0, node_assert_1.default)(Array.isArray(setCookie), "Set-Cookie header missing");
    const jwtValue = (_a = setCookie[0].match(/token=([^;]+)/)) === null || _a === void 0 ? void 0 : _a[1];
    return { csrfToken, token: jwtValue };
});
(0, node_test_1.describe)("When there is initially some services", () => {
    (0, node_test_1.beforeEach)(() => __awaiter(void 0, void 0, void 0, function* () {
        yield test_utils_1.initial.loadUsers();
        yield test_utils_1.initial.loadServices();
    }));
    (0, node_test_1.afterEach)(() => __awaiter(void 0, void 0, void 0, function* () {
    }));
    (0, node_test_1.test)("services are returned as json", () => __awaiter(void 0, void 0, void 0, function* () {
        const response = yield api
            .get(base_url)
            .expect(200)
            .expect("Content-Type", /application\/json/);
    }));
    (0, node_test_1.test)("All services are returned", () => __awaiter(void 0, void 0, void 0, function* () {
        const response = yield api.get(base_url);
        node_assert_1.default.strictEqual(response.body.length, test_utils_1.initial.SERVICES.length);
    }));
});
(0, node_test_1.describe)("When there is initially one user logged in", () => {
    (0, node_test_1.beforeEach)(() => __awaiter(void 0, void 0, void 0, function* () {
        yield user_1.default.deleteMany({});
        yield service_1.default.deleteMany({});
        const passwordHash = yield bcrypt_1.default.hash("sekret", 10);
        const newUser = new user_1.default({
            username: "root",
            password: passwordHash,
            name: "Root",
            last_name: "Rumirez",
        });
        yield newUser.save();
    }));
    (0, node_test_1.afterEach)(() => __awaiter(void 0, void 0, void 0, function* () { return yield api.post("/api/login/logout"); }));
    (0, node_test_1.test)("A valid service can be created properly", () => __awaiter(void 0, void 0, void 0, function* () {
        const initialServices = yield test_utils_1.db.services();
        const userInitialServices = (yield user_1.default.findOne({ username: "root" })).services;
        const service = {
            name: "Clases particulares MATES",
            is_delivery: true,
            delivery_scope: ["Estación Central", "Santiago"],
            on_location: true,
            location: "Santiago",
            schedule: "de lunes a viernes de 10:00AM a 21:00PM",
            description: " Ofrezco clases particulares de matemática todos los niveles",
            pricing: "10lkas la hora",
            contact: { whatsapp: "+56912345678" }
        };
        const { csrfToken, token } = yield login({ username: "root", password: "sekret" });
        const result = yield api
            .post(base_url)
            .set('Cookie', `token=${token}`)
            .set('X-CSRF-Token', csrfToken)
            .send(service)
            .expect(201)
            .expect("Content-Type", /application\/json/);
        const finalServices = yield test_utils_1.db.services();
        const userFinalServices = (yield user_1.default.findOne({ username: "root" })).services;
        node_assert_1.default.strictEqual(finalServices.length, initialServices.length + 1);
        node_assert_1.default.strictEqual(userFinalServices.length, userInitialServices.length + 1);
        node_assert_1.default.strictEqual(userFinalServices.pop().toString(), result.body.id);
    }));
});
(0, node_test_1.after)(() => __awaiter(void 0, void 0, void 0, function* () {
    yield mongoose_1.default.connection.close();
}));
