"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
/* Dependencias */
const express_1 = __importDefault(require("express"));
const mongoose_1 = __importDefault(require("mongoose"));
/* utils */
const logger_1 = __importDefault(require("./utils/logger"));
const config_1 = __importDefault(require("./utils/config"));
/* routes */
const services_1 = __importDefault(require("./routes/services"));
const users_1 = __importDefault(require("./routes/users"));
const auth_1 = __importDefault(require("./routes/auth"));
const reviews_1 = __importDefault(require("./routes/reviews"));
const testing_1 = __importDefault(require("./routes/testing"));
/* middlewares */
const errorMiddleware_1 = __importDefault(require("./middlewares/errorMiddleware"));
const cookie_parser_1 = __importDefault(require("cookie-parser"));
const cors_1 = __importDefault(require("cors"));
const path_1 = __importDefault(require("path"));
const app = (0, express_1.default)();
/* conectar mongodb */
if (config_1.default.MONGODB_URI) {
    mongoose_1.default.connect(config_1.default.MONGODB_URI, { dbName: config_1.default.MONGODB_DBNAME })
        .then(() => {
        console.log(`MongoDB Connected on ${config_1.default.MONGODB_URI} to ${config_1.default.MONGODB_DBNAME}`);
    })
        .catch((error) => {
        logger_1.default.error("error connecting to MongoDB", error.message);
    });
}
else {
    console.log("No url provided for mongodb");
}
app.use(express_1.default.json());
app.use((0, cookie_parser_1.default)());
// CORS configuration
const corsOptions = {
    origin: process.env.NODE_ENV === 'production'
        ? ['http://fullstack.dcc.uchile.cl:7104', 'http://fullstack.dcc.uchile.cl']
        : 'http://localhost:5173',
    credentials: true
};
app.use((0, cors_1.default)(corsOptions));
// API routes
app.use("/api/services", services_1.default);
app.use("/api/users", users_1.default);
app.use("/api/login", auth_1.default);
app.use("/api/reviews", reviews_1.default);
app.use("/api/testing", testing_1.default);
// Serve static files from frontend build in production
if (process.env.NODE_ENV === 'production') {
    app.use(express_1.default.static(path_1.default.join(__dirname, '../../frontend/dist')));
    app.get('*', (req, res) => {
        res.sendFile(path_1.default.join(__dirname, '../../frontend/dist/index.html'));
    });
}
app.use(errorMiddleware_1.default.unknownEndpoint);
app.use(errorMiddleware_1.default.errorHandler);
exports.default = app;
