"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const service_1 = __importDefault(require("../models/service"));
const user_1 = __importDefault(require("../models/user"));
const review_1 = __importDefault(require("../models/review"));
const getAll = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const allReviews = yield review_1.default.find({});
    res.json(allReviews);
});
const getByServiceId = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const service_id = req.params.id;
    const review = yield review_1.default.find({ service_id: service_id });
    if (!review)
        return res.status(404).end();
    return res.json(review);
});
const createOne = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const body = req.body;
    const user = yield user_1.default.findById(req.userId);
    const service = yield service_1.default.findById(req.params.id);
    if (!user)
        return res.status(400).json({ error: " user not found " });
    else if (!service)
        return res.status(400).json({ error: " service not found " });
    else if (!body.rating)
        return res.status(400).json({ error: "missing required field 'rating'" });
    const review = {
        service_id: service._id,
        user_id: user.id,
        rating: body.rating,
        comment: body.comment,
    };
    const savedReview = yield new review_1.default(review).save();
    /** TODO Actualizar Rating del servicio */
    return res.status(200).json(savedReview);
});
exports.default = { getAll, getByServiceId, createOne };
