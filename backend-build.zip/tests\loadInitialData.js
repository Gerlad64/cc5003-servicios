"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const config_1 = __importDefault(require("../src/utils/config"));
const mongoose_1 = __importDefault(require("mongoose"));
const logger_1 = __importDefault(require("../src/utils/logger"));
const test_utils_1 = require("./test_utils");
/* PARA CARGAR DATOS DE PRUEBA A LA BASE DE DATOS DE DESARROLLO O PRODUCCIÓN:
*       NODE_ENV=<development o production> npx tsx path/to/loadInitialData.ts
* */
console.log("LOADING INITIAL DATA");
if (config_1.default.MONGODB_URI) {
    mongoose_1.default.connect(config_1.default.MONGODB_URI, { dbName: config_1.default.MONGODB_DBNAME })
        .then(() => {
        console.log(`MongoDB Connected on ${config_1.default.MONGODB_URI} to ${config_1.default.MONGODB_DBNAME}`);
    })
        .catch((error) => {
        logger_1.default.error("error connecting to MongoDB", error.message);
    });
}
else {
    console.log("No url provided for mongodb");
}
const load = () => __awaiter(void 0, void 0, void 0, function* () {
    yield test_utils_1.initial.loadUsers().then(() => console.log("Users initialized"));
    yield test_utils_1.initial.loadServices().then(() => console.log("Services initialized"));
});
load().then(() => console.log("FINISHED"));
