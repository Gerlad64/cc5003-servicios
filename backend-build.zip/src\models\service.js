"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = __importDefault(require("mongoose"));
mongoose_1.default.set("strictQuery", false);
const contactSchema = new mongoose_1.default.Schema({
    whatsapp: { type: String, required: false },
    instagram: { type: String, required: false },
    telegram: { type: String, required: false },
    mail: { type: String, required: false },
});
const serviceSchema = new mongoose_1.default.Schema({
    user_id: {
        type: mongoose_1.default.Schema.Types.ObjectId,
        required: true,
        ref: "User",
    },
    name: {
        type: String,
        required: true,
    },
    category: {
        type: String,
        required: false,
    },
    rating: {
        type: Number,
        required: true,
        default: 0.0,
        min: 0.0,
        max: 5.0,
    },
    on_location: Boolean,
    is_delivery: Boolean,
    delivery_scope: [String],
    location: String,
    schedule: String,
    description: String,
    pricing: String,
    contact: contactSchema,
});
const Service = mongoose_1.default.model("Service", serviceSchema);
serviceSchema.set("toJSON", {
    transform: (_, returnedObject) => {
        var _a;
        returnedObject.id = (_a = returnedObject._id) === null || _a === void 0 ? void 0 : _a.toString();
        delete returnedObject._id;
        delete returnedObject.__v;
    },
});
exports.default = Service;
