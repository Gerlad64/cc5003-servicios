"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.me = void 0;
const bcrypt_1 = __importDefault(require("bcrypt"));
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const user_1 = __importDefault(require("../models/user"));
const config_1 = __importDefault(require("../utils/config"));
const login = (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        /** Obtener parametros de la request */
        const { username, password } = req.body;
        const user = yield user_1.default.findOne({ username });
        /** Chequear si es un login válido */
        const invalidLogin = user ? !(yield bcrypt_1.default.compare(password, user.password)) : false;
        if (invalidLogin || !user) // 2do para que el compilador no reclame que user puede ser null
            return res.status(401).json({ error: "invalid username or password" });
        /** Crear token con medidas de seguridad */
        const userForToken = {
            username: username,
            csrf: crypto.randomUUID(),
            id: user._id,
        };
        const token = jsonwebtoken_1.default.sign(userForToken, config_1.default.JWT_SECRET, { expiresIn: 60 * 60 });
        res.setHeader("X-CSRF-TOKEN", userForToken.csrf);
        res.cookie("token", token, {
            httpOnly: true,
            secure: process.env.NODE_ENV === "production",
        });
        /** ----DONE----*/
        res.status(200).send({ username: user.username });
    }
    catch (error) {
        next(error);
    }
});
const logout = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    res.clearCookie("token");
    res.status(200).send({
        message: "Logged out successfully",
    });
});
const me = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    // const body = req.body;
    const user = yield user_1.default.findById(req.userId);
    const userObject = user ? user.toObject() : null;
    const _a = userObject !== null && userObject !== void 0 ? userObject : {}, { password, _id, __v } = _a, userData = __rest(_a, ["password", "_id", "__v"]);
    res.status(200).json(userData);
});
exports.me = me;
exports.default = { login, logout, me: exports.me };
