"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const app_1 = __importDefault(require("../../src/app"));
const node_test_1 = require("node:test");
const node_assert_1 = __importDefault(require("node:assert"));
const test_utils_1 = require("../test_utils");
const supertest_1 = __importDefault(require("supertest"));
const mongoose_1 = __importDefault(require("mongoose"));
const api = (0, supertest_1.default)(app_1.default);
const base_url = "/api/users";
(0, node_test_1.describe)("When there is initially some users", () => {
    (0, node_test_1.beforeEach)(() => __awaiter(void 0, void 0, void 0, function* () {
        yield test_utils_1.initial.loadUsers();
    }));
    (0, node_test_1.afterEach)(() => __awaiter(void 0, void 0, void 0, function* () {
    }));
    (0, node_test_1.test)("users are returned as json", () => __awaiter(void 0, void 0, void 0, function* () {
        yield api
            .get(base_url)
            .expect(200)
            .expect("Content-Type", /application\/json/);
    }));
    (0, node_test_1.test)("All users are returned", () => __awaiter(void 0, void 0, void 0, function* () {
        const response = yield api.get(base_url);
        node_assert_1.default.strictEqual(response.body.length, test_utils_1.initial.USERS.length);
    }));
    (0, node_test_1.test)("A user can be created", () => __awaiter(void 0, void 0, void 0, function* () {
        const newUser = {
            username: "test",
            password: "test1234",
            name: "Tomás",
            last_name: "Estero"
        };
        yield api
            .post(base_url)
            .send(newUser)
            .expect(201)
            .expect("Content-Type", /application\/json/);
        const usersInDb = yield test_utils_1.db.users();
        node_assert_1.default.strictEqual(usersInDb.length, test_utils_1.initial.USERS.length + 1);
    }));
    (0, node_test_1.test)("Creation fails with proper statuscode and message if username already taken", () => __awaiter(void 0, void 0, void 0, function* () {
        const newUser = {
            username: "jperez",
            password: "test1234",
            name: "José",
            last_name: "Perez"
        };
        const result = yield api
            .post(base_url)
            .send(newUser)
            .expect(400)
            .expect("Content-Type", /application\/json/);
        const usersInDb = yield test_utils_1.db.users();
        (0, node_assert_1.default)(result.body.error.includes("expected `username` to be unique"));
        node_assert_1.default.strictEqual(usersInDb.length, test_utils_1.initial.USERS.length);
    }));
});
(0, node_test_1.after)(() => __awaiter(void 0, void 0, void 0, function* () {
    yield mongoose_1.default.connection.close();
}));
