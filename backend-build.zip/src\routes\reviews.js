"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const review_1 = __importDefault(require("../controllers/review"));
const authMiddleware_1 = require("../middlewares/authMiddleware");
const router = express_1.default.Router();
router.get("/", review_1.default.getAll);
router.get("/service/:id", review_1.default.getByServiceId);
router.post("/:id", authMiddleware_1.authenticate, review_1.default.createOne);
exports.default = router;
