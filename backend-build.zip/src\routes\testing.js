"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const testing_1 = __importDefault(require("../controllers/testing"));
const router = express_1.default.Router();
router.post("/reset", testing_1.default.reset);
exports.default = router;
