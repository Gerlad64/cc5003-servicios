"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const auth_1 = __importDefault(require("../controllers/auth"));
const userMiddleware_1 = require("../middlewares/userMiddleware");
const router = express_1.default.Router();
router.post('/', auth_1.default.login);
router.post('/logout', auth_1.default.logout);
router.get("/me", userMiddleware_1.withUser, auth_1.default.me);
exports.default = router;
