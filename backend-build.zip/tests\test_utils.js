"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.db = exports.initial = void 0;
const service_1 = __importDefault(require("../src/models/service"));
const user_1 = __importDefault(require("../src/models/user"));
const USERS = [
    {
        username: "jdoe",
        password: "$2b$10$aJcUj10QQw3YffxuHDmubOOaCt.Ir3LqW5kTET8ypsIdx51h0HXYy",
        name: "John",
        last_name: "Doe",
        biography: "I like turtles",
    },
    {
        username: "jperez",
        password: "$2b$10$bI70RNYdYZPemcensoCSYuC2ngmszhOmHj4QiRiOion6u.CrJfz7K",
        name: "Juan",
        last_name: "Perez",
        biography: "Me gustan las tortugas.",
    },
    {
        username: "jpierre",
        password: '$2b$10$20YgDfVNgPOxaFXcbQkcv.8LS9w2UyP7G6TOQDeHn5CDZSrhZalI.',
        name: "Jean",
        last_name: "Pierre",
        biography: "J'aime les tortues."
    },
    {
        username: "jpetters",
        password: '$2b$10$rGNql4lfxUkyscbuO5M6xOCR75sX41weIY5gsX3nDAmBULDDYeHeq',
        name: "Johann",
        last_name: "Peters",
        biography: "Ich mag es des Tørtüggens "
    }
];
const SERVICES = [
    {
        "name": "Clases de guitarra acústica",
        "rating": 4.8,
        "is_delivery": false,
        "on_location": true,
        "location": "San Miguel",
        "schedule": "Lunes a viernes de 16:00 a 20:00",
        "description": "Clases personalizadas de guitarra acústica para principiantes y nivel intermedio.",
        "pricing": "Por hora",
        "contact": {
            "whatsapp": "+56912345678",
            "instagram": "guitarra_la_roca",
            "mail": "profeguitarra@example.com"
        }
    },
    {
        "name": "Reparación de bicicletas a domicilio",
        "rating": 5.0,
        "is_delivery": true,
        "delivery_scope": ["Ñuñoa", "Providencia", "Macul"],
        "on_location": false,
        "schedule": "Todos los días de 9:00 a 19:00",
        "description": "Servicio completo de mantención y reparación de bicicletas en la comodidad de tu casa.",
        "pricing": "Presupuesto según reparación",
        "contact": {
            "whatsapp": "+56987654321",
            "telegram": "@bikefixchile"
        }
    },
    {
        "name": "Paseo de perros",
        "rating": 4.2,
        "is_delivery": true,
        "delivery_scope": ["La Reina", "Peñalolén", "Ñuñoa"],
        "on_location": false,
        "schedule": "Lunes a viernes de 7:30 a 12:00",
        "description": "Paseo diario de perros, individual o en grupos pequeños. Servicio responsable y con experiencia.",
        "pricing": "Mensual o por paseo",
        "contact": {
            "whatsapp": "+56911223344",
            "mail": "paseadordeperros@gmail.com"
        }
    },
    {
        "name": "Asesoría en tesis y trabajos universitarios",
        "rating": 0.0,
        "is_delivery": true,
        "delivery_scope": ["Independencia", "San Joaquín", "Estación Central"],
        "on_location": false,
        "schedule": "Horario flexible, previa coordinación",
        "description": "Asesoría académica para la redacción, corrección y presentación de tesis de pregrado y posgrado.",
        "pricing": "Por proyecto o por hora",
        "contact": {
            "mail": "asesoriatesis@protonmail.com",
            "telegram": "@tesis_ayuda"
        }
    }
];
/** Elimina datos y luego carga datos de prueba a la base de datos de testing */
const loadUsers = () => __awaiter(void 0, void 0, void 0, function* () {
    yield user_1.default.deleteMany({});
    yield user_1.default.insertMany(USERS);
});
const loadServices = () => __awaiter(void 0, void 0, void 0, function* () {
    yield service_1.default.deleteMany({});
    const users = yield user_1.default.find({});
    const services = yield service_1.default.insertMany(SERVICES
        .slice(0, users.length)
        .map((s, i) => (Object.assign(Object.assign({}, s), { user_id: users[i]._id }))));
    services.map((s, i) => {
        const user = users[i];
        user.services.push(s.id);
        user.save();
    });
});
const usersInDb = () => __awaiter(void 0, void 0, void 0, function* () {
    const users = yield user_1.default.find({});
    return users.map(u => u.toJSON());
});
const servicesInDb = () => __awaiter(void 0, void 0, void 0, function* () {
    const services = yield service_1.default.find({});
    return services.map(s => s.toJSON());
});
exports.initial = { loadServices, loadUsers, USERS, SERVICES };
exports.db = { users: usersInDb, services: servicesInDb };
