"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const service_1 = __importDefault(require("../models/service"));
const user_1 = __importDefault(require("../models/user"));
/** Trae todos los servicios */
const getAll = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const allServices = yield service_1.default.find({});
    res.json(allServices);
});
/** Trae un servicio por su id */
const getById = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const id = req.params.id;
    const service = yield service_1.default.findById(id);
    if (!service)
        return res.status(404).end();
    return res.json(service);
});
/** Crea un servicio, el usurio debe estar autenticado */
const createOne = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const body = req.body;
    const user = yield user_1.default.findById(req.userId);
    if (!user)
        return res.status(400).json({ error: " user not found " });
    else if (!body.name)
        return res.status(400).json({ error: " titulo del servicio no encontrado " });
    const service = {
        user_id: user.id,
        name: body.name,
        is_delivery: body.is_delivery,
        delivery_scope: body.delivery_scope,
        on_location: body.on_location,
        location: body.location,
        schedule: body.schedule,
        description: body.description,
        pricing: body.pricing,
        contact: body.contact,
    };
    const savedService = yield new service_1.default(service).save();
    user.services.push(savedService.id);
    yield user.save();
    return res.status(201).json(savedService);
});
exports.default = { getAll, getById, createOne };
