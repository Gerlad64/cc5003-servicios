"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const bcrypt_1 = __importDefault(require("bcrypt"));
const user_1 = __importDefault(require("../models/user"));
const getAll = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const users = yield user_1.default.find({});
    res.json(users);
});
const getById = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const id = req.params.id;
    const user = yield user_1.default.findById(id);
    if (!user)
        return res.status(404).end();
    return res.json(user);
});
const createOne = (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { username, password, name, last_name } = req.body;
        // Validar que todos los campos requeridos estén presentes
        if (!username || !password || !name || !last_name) {
            return res.status(400).json({
                error: "Todos los campos son requeridos"
            });
        }
        // Verificar si el usuario ya existe
        const existingUser = yield user_1.default.findOne({ username });
        if (existingUser) {
            return res.status(400).json({
                error: "El nombre de usuario ya está en uso"
            });
        }
        const saltRounds = 10;
        const hashed = yield bcrypt_1.default.hash(password, saltRounds);
        const user = new user_1.default({
            username: username,
            password: hashed,
            name: name,
            last_name: last_name,
        });
        const savedUser = yield user.save();
        res.status(201).json(savedUser);
    }
    catch (error) {
        // Manejar errores de validación de Mongoose
        if (error.name === 'ValidationError') {
            return res.status(400).json({
                error: "Error de validación: " + error.message
            });
        }
        // Manejar errores de duplicado (código 11000)
        if (error.code === 11000) {
            return res.status(400).json({
                error: "El nombre de usuario ya está en uso"
            });
        }
        next(error);
    }
});
exports.default = { createOne, getAll, getById };
