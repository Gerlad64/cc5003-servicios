"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
/* controllers */
const service_1 = __importDefault(require("../controllers/service"));
const authMiddleware_1 = require("../middlewares/authMiddleware");
const router = express_1.default.Router();
router.get('/', service_1.default.getAll);
router.get('/:id', service_1.default.getById);
router.post('/', authMiddleware_1.authenticate, service_1.default.createOne);
exports.default = router;
