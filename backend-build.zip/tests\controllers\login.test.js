"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const app_1 = __importDefault(require("../../src/app"));
const node_test_1 = require("node:test");
const node_assert_1 = __importDefault(require("node:assert"));
const test_utils_1 = require("../test_utils");
const supertest_1 = __importDefault(require("supertest"));
const mongoose_1 = __importDefault(require("mongoose"));
const user_1 = __importDefault(require("../../src/models/user"));
const config_1 = __importDefault(require("../../src/utils/config"));
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const bcrypt_1 = __importDefault(require("bcrypt"));
const api = (0, supertest_1.default)(app_1.default);
const base_url = "/api/login";
const user = {
    username: "root",
    password: "sekret",
};
const login = (user) => __awaiter(void 0, void 0, void 0, function* () {
    return yield api
        .post(base_url)
        .send(user);
});
(0, node_test_1.describe)("When there's initially some users in db", () => {
    (0, node_test_1.beforeEach)(() => __awaiter(void 0, void 0, void 0, function* () {
        yield test_utils_1.initial.loadUsers();
        const passwordHash = yield bcrypt_1.default.hash("sekret", 10);
        const newUser = new user_1.default({
            username: "root",
            password: passwordHash,
            name: "Root",
            last_name: "Rumirez",
        });
        yield newUser.save();
    }));
    (0, node_test_1.describe)("When login succeeds with valid credentials", () => {
        (0, node_test_1.test)("Check username in response body", () => __awaiter(void 0, void 0, void 0, function* () {
            const result = yield login(user);
            node_assert_1.default.strictEqual(result.status, 200);
            node_assert_1.default.match(result.headers["content-type"], /application\/json/);
            (0, node_assert_1.default)(result.body.username === user.username);
        }));
        (0, node_test_1.test)("Check CSRF header", () => __awaiter(void 0, void 0, void 0, function* () {
            const result = yield login(user);
            const csrfToken = result.headers["x-csrf-token"];
            (0, node_assert_1.default)(typeof csrfToken === "string", "Missing X-CSRF-Token header");
            (0, node_assert_1.default)(csrfToken.length > 10, "CSRF token too short");
        }));
        (0, node_test_1.test)("Check JWT in cookie", () => __awaiter(void 0, void 0, void 0, function* () {
            var _a;
            const result = yield login(user);
            const csrfToken = result.headers["x-csrf-token"];
            const setCookie = result.headers["set-cookie"];
            (0, node_assert_1.default)(Array.isArray(setCookie), "Set-Cookie header missing");
            const jwtValue = (_a = setCookie[0].match(/token=([^;]+)/)) === null || _a === void 0 ? void 0 : _a[1];
            (0, node_assert_1.default)(jwtValue, "JWT not found in cookie");
            const payload = jsonwebtoken_1.default.verify(jwtValue, config_1.default.JWT_SECRET);
            (0, node_assert_1.default)(payload && typeof payload === "object");
            node_assert_1.default.strictEqual(payload.username, user.username);
            node_assert_1.default.strictEqual(payload.csrf, csrfToken);
        }));
        (0, node_test_1.test)("Loggout works successfully", () => __awaiter(void 0, void 0, void 0, function* () {
            yield login(user);
            const result = yield api.post(base_url + "/logout").expect(200);
            (0, node_assert_1.default)(result.body.message === "Logged out successfully");
        }));
    });
    (0, node_test_1.describe)("When login fails with invalid credentials", () => {
        (0, node_test_1.test)("Check status code", () => __awaiter(void 0, void 0, void 0, function* () {
            const result = yield login({
                username: "root",
                password: "wrongpassword",
            });
            node_assert_1.default.strictEqual(result.status, 401);
        }));
    });
});
(0, node_test_1.after)(() => __awaiter(void 0, void 0, void 0, function* () {
    yield mongoose_1.default.connection.close();
}));
